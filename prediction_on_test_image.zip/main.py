import os
import numpy as np
from keras.models import Sequential
from keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout
from keras.callbacks import EarlyStopping
from keras.preprocessing.image import ImageDataGenerator
from matplotlib import pyplot as plt

# Set up early stopping
early_stopping = EarlyStopping(patience=10, monitor='val_loss')

# Function to load the dataset
def load_dataset(base_dir):
    train_dir = os.path.join(base_dir, 'Train')
    test_dir = os.path.join(base_dir, 'Test')

    train_datagen = ImageDataGenerator(rescale=1/255, shear_range=0.2, rotation_range=25)
    test_datagen = ImageDataGenerator(rescale=1/255)

    train_set = train_datagen.flow_from_directory(train_dir, target_size=(32, 32), batch_size=256, class_mode='categorical')
    test_set = test_datagen.flow_from_directory(test_dir, target_size=(32, 32), batch_size=256, class_mode='categorical')

    return train_set, test_set

# Function to create the CNN model
def create_model():
    classifier = Sequential()

    classifier.add(Conv2D(filters=32, kernel_size=(3, 3), activation='relu', input_shape=(32, 32, 3)))
    classifier.add(Conv2D(filters=64, kernel_size=(3, 3), activation='relu'))
    classifier.add(MaxPooling2D(pool_size=(2, 2)))
    classifier.add(Conv2D(filters=64, kernel_size=(3, 3), activation='relu'))
    classifier.add(Conv2D(filters=64, kernel_size=(3, 3), activation='relu'))
    classifier.add(MaxPooling2D(pool_size=(2, 2)))
    classifier.add(Dropout(0.2))

    classifier.add(Flatten())

    classifier.add(Dense(units=128, activation='relu'))
    classifier.add(Dropout(0.2))

    classifier.add(Dense(units=36, activation='softmax'))

    classifier.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

    return classifier

def main():
    base_dir = 'main/dataset'
    train_set, test_set = load_dataset(base_dir)
    classifier = create_model()

    history = classifier.fit(train_set, epochs=100, validation_data=test_set, callbacks=[early_stopping])

    scores = classifier.evaluate(train_set)
    print("Accuracy on training set: %.2f%%" % (scores[1] * 100))

    scores = classifier.evaluate(test_set)
    print("Accuracy on test set: %.2f%%" % (scores[1] * 100))

    classifier_json = classifier.to_json()

    with open("CNN_DevanagariHandWrittenCharacterRecognition.json", "w") as json_file:
        json_file.write(classifier_json)

    classifier.save_weights("CNN_DevanagariHandWrittenCharacterRecognition_weights.h5")
    print('Saved model to disk')

    classifier.save('devanagari_cnn_model.h5')

    # summarize history for accuracy
    plt.plot(history.history['accuracy'])
    plt.plot(history.history['val_accuracy'])
    plt.title('model accuracy')
    plt.ylabel('accuracy')
    plt.xlabel('epoch')
    plt.legend(['train', 'test'], loc='upper left')
    plt.show()
    # summarize history for loss
    plt.plot(history.history['loss'])
    plt.plot(history.history['val_loss'])
    plt.title('model loss')
    plt.ylabel('loss')
    plt.xlabel('epoch')
    plt.legend(['train', 'test'], loc='upper left')
    plt.show()

if __name__ == "__main__":
    main()
