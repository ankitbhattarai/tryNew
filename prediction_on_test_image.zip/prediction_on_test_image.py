import os
import numpy as np
import matplotlib.pyplot as plt
from keras.models import model_from_json
from keras.preprocessing.image import ImageDataGenerator, img_to_array, load_img

# Load model architecture from JSON file
with open("CNN_DevanagariHandWrittenCharacterRecognition.json", "r") as json_file:
    loaded_model_json = json_file.read()

# Create model from loaded JSON
loaded_model = model_from_json(loaded_model_json)

# Load weights into the model
loaded_model.load_weights("devanagari_cnn_model.h5")

# Compile the model (necessary for making predictions)
loaded_model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

# Load mapping of class indices to class names used during training
class_names = sorted(os.listdir('main/dataset/Train'))
num_classes = len(class_names)

# Function to preprocess the image
def preprocess_image(image_path):
    img = load_img(image_path, target_size=(32, 32))
    img_array = img_to_array(img)
    img_array = np.expand_dims(img_array, axis=0)
    img_array /= 255.0
    return img_array

# Load a new test image and make a prediction
test_image_path = "validation_images/6.jpg"
test_image = preprocess_image(test_image_path)

# Make prediction
predictions = loaded_model.predict(test_image)
predicted_class_index = np.argmax(predictions)
predicted_class_name = class_names[predicted_class_index]


plt.imshow(load_img(test_image_path))
plt.title("Predicted Class: " + predicted_class_name)
plt.axis('off')
plt.show()
